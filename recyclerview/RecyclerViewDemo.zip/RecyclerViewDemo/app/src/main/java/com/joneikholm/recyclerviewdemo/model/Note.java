package com.joneikholm.recyclerviewdemo.model;

public class Note {
   public String headline;
   public String body;
}
