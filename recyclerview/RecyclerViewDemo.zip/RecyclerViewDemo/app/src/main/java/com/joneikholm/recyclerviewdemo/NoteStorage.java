package com.joneikholm.recyclerviewdemo;

import com.joneikholm.recyclerviewdemo.model.Note;

import java.util.ArrayList;

public class NoteStorage {
    public static ArrayList<Note> list = new ArrayList<>();
}
